package com.example.mad_assignment;

public interface JobRecyclerViewInterface {
    void onItemClick(int position);
}
