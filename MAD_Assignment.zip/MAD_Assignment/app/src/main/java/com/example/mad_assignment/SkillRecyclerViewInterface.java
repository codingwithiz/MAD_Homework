package com.example.mad_assignment;

public interface SkillRecyclerViewInterface {
    void onItemClick(int position);
}
