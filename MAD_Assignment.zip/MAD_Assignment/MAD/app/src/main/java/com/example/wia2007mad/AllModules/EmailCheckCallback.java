package com.example.wia2007mad.AllModules;

public interface EmailCheckCallback {
    void onEmailChecked(boolean exists);
}
